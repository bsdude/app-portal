// interface describing base user app
export interface IUserAppBase {
    base_app_name: string;
    base_app_description: string;
    base_app_version: string;
    base_app_url: string;
    base_app_license: string;
    base_app_labels: string[];
}