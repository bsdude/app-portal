export interface IUserAppArgument {
    arg_type: number;
    arg_array_separator: string;
    arg_is_array: boolean;
    arg_default_value: string;
    arg_prefix: string;
    arg_separator: string;
    arg_position: number;
    arg_title: string;
    arg_description: string;
    arg_is_input: boolean;
    arg_is_readonly: boolean;
};