export interface IUserAppOutput {
    id: number; // Identifier uniq
    name: string; // Name or fullname
    email: string; // Email
    dateOfBirth: string; // Date fo birth
}