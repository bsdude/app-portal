import { IUserAppArgument } from "./UserAppArgument";
import { IUserAppBase } from "./UserAppBase";
import { IUserAppOutput } from "./UserAppOutput";

export interface IUserApp extends IUserAppBase {
    app_container: string;
    app_container_test_cmd: string;
    app_container_test_output: string;

    app_tool_type: number;
    app_svc_type: number;

    app_resources_threads: string;
    app_resources_ram: string;
    app_command_name: string;

    app_command_success: string[];
    app_command_failure: string[];

    app_arguments: IUserAppArgument[];
    app_outputs: IUserAppOutput[];
};