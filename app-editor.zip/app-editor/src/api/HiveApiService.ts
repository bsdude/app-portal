import HttpApiService from "./HttpApiService";
import { IContact } from "../models/contact";
import { IUserApp } from "../models/UserApp";



const API_BASE = `${process.env.REACT_APP_API_URI}`;

const HIVE_CMD_PROPSET = "propset2";
const HIVE_CMD_PROPGET = "propget";
const HIVE_CMD_PROPSPEC = "propspec";
const HIVE_CMD_OBJLIST = "objList";

const HIVE_ENDPOINT = `${API_BASE}/dna.cgi`;

export class HiveApi extends HttpApiService {
    constructor() {
        super(`${API_BASE}`);
    }

    makeHiveUrl = (command: string) => {
        return `${API_BASE}?api=0&cmdr=${command}`;
    };

    // creating and editing obj metadata
    createUserApp = (data: IUserApp) => {
        interface ExtendedAppData extends IUserApp {
            _id: string;
            _type: string;
        };

        const ext_data = data as ExtendedAppData;
        ext_data._id = "$newid()";
        ext_data._type = "user_app"


        interface HiveRequest {
            cmdr: string;
            parse: string;
        }


        const post_data = <HiveRequest>{cmdr: HIVE_CMD_PROPSET, parse: JSON.stringify(ext_data)};

        return this.create(`${HIVE_ENDPOINT}`, post_data);
    };

    // login
    doLogin = () => {
        return this.get(`${HIVE_ENDPOINT}` + "cmd=login&follow=appportal");
    }

    //#region Contact
    getContactById = (id: number) => {
        return this.get(`${HIVE_ENDPOINT}/${id}`);
    };

    getAllContacts = () => {
        const response = this.get(`${HIVE_ENDPOINT}`);
        return response
    };

    createContact = (data: IContact) => {
        return super.create(`${HIVE_ENDPOINT}`, data);
    };

    updateContact = (data: IContact) => {
        return super.update(`${HIVE_ENDPOINT}`, data);
    };
    //#endregion Contact

}

export const HiveApiService = new HiveApi();
