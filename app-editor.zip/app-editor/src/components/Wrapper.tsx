import React from "react";

const Wrapper: React.FC = ({ children }) => (
  <div className="wrapper">{children}</div>
);

export default Wrapper;
