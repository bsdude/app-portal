import React from "react";
import { Helmet } from "react-helmet-async";
import { Button, Card, Col, Container, Form, Row } from "react-bootstrap";
import Select from "react-select";



import Header from "./Header";
import { HiveApiService } from "../../api/HiveApiService";
import { IUserApp } from "../../models/UserApp";
import * as Yup from "yup";
import { Formik } from "formik";

import { FormRow, ImageRow } from "./General";
import { ResFormRow, ResImageRow } from "./Resources";
import { IOModals, IOFormRow, IOImageRow } from "./IO";




interface IOwnState {
   contact: IUserApp;
}

const options = [
   { value: "AK", label: "Annotations" },
   { value: "HI", label: "AMR" },
   { value: "CA", label: "Classifications" },
   { value: "NV", label: "Downloaders" },
   { value: "OR", label: "DNA Tools" },
   { value: "WA", label: "Other" },
]

const EditorWhole = () => (
   <React.Fragment>
      <Helmet title="General Settings" />
      <Container fluid className="p-0">
         <Header />
         <Row>
            <Col lg="12">
               <FormRow />
               <ImageRow />
               <ResFormRow />
               <ResImageRow />
               <Row>
                  <Col lg="12">

                     <IOModals />
                  </Col>
               </Row>
               <IOFormRow />
               <IOImageRow />
            </Col>
         </Row>
      </Container>
   </React.Fragment>
);

export default EditorWhole;
