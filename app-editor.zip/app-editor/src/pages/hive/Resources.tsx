import React from "react";
import { Helmet } from "react-helmet-async";
import { Button, Card, Col, Container, Form, Row } from "react-bootstrap";
import Select from "react-select";



import Header from "./Header";

const options = [
  { value: "AK", label: "Annotations" },
  { value: "HI", label: "AMR" },
  { value: "CA", label: "Classifications" },
  { value: "NV", label: "Downloaders" },
  { value: "OR", label: "DNA Tools" },
  { value: "WA", label: "Other" },
]

const ResFormRow = () => (
  <Card>
    <Card.Header>
      <Card.Title>Computational Resources</Card.Title>
      <h6 className="card-subtitle text-muted">Please refer to tool documentation to select appropriate system resources</h6>
    </Card.Header>
    <Card.Body>
      <Form>
        <Row>
          <Col md={6}>
            <Form.Group className="mb-3">
              <Form.Label>Recommended Number of Parallel Threads</Form.Label>
              <Form.Control type="text" name="app_name" placeholder="1" />
            </Form.Group>
          </Col>
          <Col md={6}>
            <Form.Group className="mb-3">
              <Form.Label>Amount of RAM</Form.Label>
              <Form.Select
                id="exampleCustomSelect"
                name="customSelect"
                className="mb-3"
              >
                <option value="">1GB</option>
                <option>4GB</option>
                <option>8GB</option>
                <option>16GB</option>
                <option>32GB</option>
              </Form.Select>
            </Form.Group>
          </Col>
        </Row>

        <Row>
          <Col md={6}>
            <Form.Group className="mb-3">
              <Form.Label>GPU Resources</Form.Label>
              <Form.Select
                id="exampleCustomSelect"
                name="customSelect"
                className="mb-3"
              >
                <option value="">Not Supported</option>
                <option>Optional</option>
                <option>Required</option>
              </Form.Select>
            </Form.Group>
            <Form.Group className="mb-3">
              <Form.Check
                type="switch"
                id="exampleCustomSwitch"
                name="customSwitch"
                label="Support multiple GPU"
              />
            </Form.Group>
          </Col>
          <Col md={6}>
            <Form.Group className="mb-3">
              
            </Form.Group>
          </Col>

        </Row>

      </Form>
    </Card.Body>
  </Card>
);

const ResImageRow = () => (
  <Card>
    <Card.Header>
      <Card.Title>App Return Codes</Card.Title>
      <h6 className="card-subtitle text-muted">Application executable return code to identify successful execution</h6>
    </Card.Header>
    <Card.Body>
      <Form>
        <Row>
          <Col md={6}>
            <Form.Group className="mb-3">
              <Form.Label>Success Codes</Form.Label>
              <Form.Control
                as="textarea"
                placeholder="0"
                style={{ height: "100px" }}
              />
            </Form.Group>
          </Col>
          <Col md={6}>
            <Form.Group className="mb-3">
              <Form.Label>Failure Codes</Form.Label>
              <Form.Control
                as="textarea"
                placeholder="1, 2, 126, 128, 130, 255"
                style={{ height: "100px" }}
              />
            </Form.Group>
          </Col>
        </Row>

      </Form>
    </Card.Body>
  </Card>
);

const EditorResources = () => (
  <React.Fragment>
    <Helmet title="General Settings" />
    <Container fluid className="p-0">
      <Header />
      <Row>
        <Col lg="12">
          <ResFormRow />
          <ResImageRow />
          <Button variant="primary">Save</Button>
        </Col>
      </Row>
    </Container>
  </React.Fragment>
);

export default EditorResources;
export {ResFormRow, ResImageRow}
