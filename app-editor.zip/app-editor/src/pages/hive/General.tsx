import React from "react";
import { Helmet } from "react-helmet-async";
import { Button, Card, Col, Container, Form, Row } from "react-bootstrap";
import Select from "react-select";



import Header from "./Header";
import { HiveApiService } from "../../api/HiveApiService";
import { IUserApp } from "../../models/UserApp";
import * as Yup from "yup";
import { Formik } from "formik";

interface IOwnState {
  contact: IUserApp;
}

const options = [
  { value: "AK", label: "Annotations" },
  { value: "HI", label: "AMR" },
  { value: "CA", label: "Classifications" },
  { value: "NV", label: "Downloaders" },
  { value: "OR", label: "DNA Tools" },
  { value: "WA", label: "Other" },
]

const FormRow = () => {
  return (
    <Formik
      initialValues={{
        base_app_name: "",
        base_app_description: "",
        base_app_url: "",
        submit: false,
      }}
      onSubmit={async (values, { setErrors, setStatus, setSubmitting }) => {
        try {
          console.log(`ContactCreation::handleSubmit=>contact ${JSON.stringify(values)}`);
          const user_app =  values as unknown as IUserApp;
          const response = await HiveApiService.createUserApp(user_app);
          console.log(`${JSON.stringify(response)}`)
        } catch (error: any) {
          const message = error.message || "Something went wrong";
          setStatus({ success: false });
          setErrors({ submit: message });
          setSubmitting(false);
        }
      }}
    >
      {({
        errors,
        handleBlur,
        handleChange,
        handleSubmit,
        isSubmitting,
        touched,
        values,
      }) => (
        <Form onSubmit={handleSubmit}>
          <Card>
            <Card.Header>
              <Card.Title>General Settings</Card.Title>
              <h6 className="card-subtitle text-muted">Please fill general app information</h6>
            </Card.Header>
            <Card.Body>

              <Row>
                <Col md={6}>
                  <Form.Group className="mb-3">
                    <Form.Label>App Name</Form.Label>
                    <Form.Control type="text" name="base_app_name" placeholder="Enter app name"
                     value={values.base_app_name}
                     onBlur={handleBlur}
                     onChange={handleChange}
                     />
                  </Form.Group>
                  <Form.Group className="mb-3">
                    <Form.Label>App Description</Form.Label>
                    <Form.Control type="text" name="base_app_description" placeholder="Canu is a fork of the Celera Assembler, designed for high-noise single-molecule sequencing"
                     value={values.base_app_description}
                     onBlur={handleBlur}
                     onChange={handleChange}
                    />
                  </Form.Group>

                  <Form.Group className="mb-3">
                    <Form.Label>Source URL</Form.Label>
                    <Form.Control type="text" name="base_app_url" placeholder="https://github.com/marbl/canu"
                    value={values.base_app_url}
                    onBlur={handleBlur}
                    onChange={handleChange}
                    />
                  </Form.Group>
                </Col>
                <Col md={6}>
                  <Form.Group className="mb-3">
                    <Form.Label>App Version</Form.Label>
                    <Form.Control type="text" name="base_app_version" placeholder="2.2" />
                  </Form.Group>
                  <Form.Group className="mb-3">
                    <Form.Label>App License</Form.Label>
                    <Form.Select
                      id="exampleCustomSelect"
                      name="base_app_license"
                      className="mb-3"
                    >
                      <option value="">GPL</option>
                      <option>MIT</option>
                      <option>Apache</option>
                      <option>BSD</option>
                      <option>LGPL</option>
                      <option>Other</option>
                    </Form.Select>
                  </Form.Group>
                  <Form.Group className="mb-3">
                    <Form.Label>Labels</Form.Label>
                    <Select
                      name="base_app_labels"
                      className="react-select-container"
                      classNamePrefix="react-select"
                      options={options}
                      isMulti
                    />
                  </Form.Group>


                </Col>
              </Row>
            </Card.Body>
          </Card>
        </Form>
      )}
    </Formik>
  );
}

const ImageRow = () => (
  <Card>
    <Card.Header>
      <Card.Title>App Image Settings</Card.Title>
      <h6 className="card-subtitle text-muted">Acceptable formats are Singularity and Docker</h6>
    </Card.Header>
    <Card.Body>
      <Form>
        <Row>

          <Col md={6}>
            <Form.Group className="mb-3">
              <Form.Label>Select App Image</Form.Label>
              <Form.Select name="app_image">
                <option>Canu_2.2_Docker.img</option>
                <option>Some_Other_Image_Docker.img</option>
                <option>Yet_Another_Image_Docker.img</option>
                <option disabled>_________</option>
                <option>Upload a new image...</option>
              </Form.Select>
            </Form.Group>
          </Col>
          <Col md={6}>
            <Form.Group className="mb-3">
              <Form.Label>Executable with full path</Form.Label>
              <Form.Control type="text" name="app_executable" placeholder="/opt/canu/bin/canu" />
            </Form.Group>
          </Col>
        </Row>
        <Row>
          <Col md={12}>
            <Form.Group className="mb-3">
              <Form.Label>Test case command line arguments</Form.Label>
              <Form.Control type="text" name="app_cli" placeholder="canu --help" />
            </Form.Group>
          </Col>
        </Row>
        <Row>
          <Col md={12}>
            <Form.Control
              as="textarea"
              placeholder="canu [-haplotype|-correct|-trim] \
          [-s <assembly-specifications-file>] \
          -p <assembly-prefix> \
          -d <assembly-directory> \
          genomeSize=<number>[g|m|k] \
          [other-options] \
          [-trimmed|-untrimmed|-raw|-corrected] \
          [-pacbio|-nanopore|-pacbio-hifi] *fastq"
              style={{ height: "200px" }}
            />
          </Col>
        </Row>
      </Form>

    </Card.Body>
  </Card>
);

const EditorGeneral = () => (
  <React.Fragment>
    <Helmet title="General Settings" />
    <Container fluid className="p-0">
      <Header />
      <Row>
        <Col lg="12">
          <FormRow />
          <ImageRow />
          <Button variant="primary">Save</Button>
        </Col>
      </Row>
    </Container>
  </React.Fragment>
);
export {FormRow, ImageRow};
export default EditorGeneral;
