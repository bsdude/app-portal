import React from "react";
import { Helmet } from "react-helmet-async";

import {
  Badge,
  Button,
  Card,
  Col,
  Container,
  ListGroup,
  ProgressBar,
  Row,
} from "react-bootstrap";

import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faPlus } from "@fortawesome/free-solid-svg-icons";

import avatar1 from "../../assets/img/avatars/avatar.jpg";
import avatar2 from "../../assets/img/avatars/avatar-2.jpg";
import avatar3 from "../../assets/img/avatars/avatar-3.jpg";

import unsplash1 from "../../assets/img/photos/unsplash-1.jpg";
import unsplash2 from "../../assets/img/photos/unsplash-2.jpg";
import unsplash3 from "../../assets/img/photos/unsplash-3.jpg";

import canuimg from "../../assets/img/canu.png";
import alphafold  from "../../assets/img/alphafold.png";
import blast  from "../../assets/img/blast-ct.png";

import { useNavigate } from "react-router-dom";


interface ProjectType {
  name: string;
  state: string;
  color: string;
  percentage: string;
  description: string;
  image?: string;
}

const Project = ({
  name,
  state,
  color,
  percentage,
  description,
  image,
}: ProjectType) => {
  const navigate = useNavigate();

  return (
  <Card>
    {image ? <Card.Img src={image} alt="Card image cap" /> : ""}
    <Card.Header className="px-4 pt-4">
      <Card.Title className="mb-0">{name}</Card.Title>
      <Badge className="my-2" bg={color}>
        {state}
      </Badge>
    </Card.Header>
    <Card.Body className="px-4 pt-2">
      <p>{description}</p>

      <img
        src={avatar3}
        width="28"
        height="28"
        className="rounded-circle me-2"
        alt="Avatar"
      />
      <img
        src={avatar2}
        width="28"
        height="28"
        className="rounded-circle me-2"
        alt="Avatar"
      />
      <img
        src={avatar1}
        width="28"
        height="28"
        className="rounded-circle me-2"
        alt="Avatar"
      />
      <p><Button className="my-2" onClick={ () =>     navigate('/apps/editor?app=1') }>Edit</Button></p>
    </Card.Body>
  </Card>
);
  }

const Apps = () => {
  const navigate = useNavigate();
  return (
  <React.Fragment>
    <Helmet title="Projects" />
    <Container fluid className="p-0">
      <Button variant="primary" className="float-end mt-n1" onClick={ () =>     navigate('/apps/editor?app=1') }>
        <FontAwesomeIcon icon={faPlus} /> Create New App
      </Button>
      <h1 className="h3 mb-3">Apps</h1>

      <Row>
 
        <Col md="6" lg="3">
          <Project
            name="Canu v2"
            state="In progress"
            color="warning"
            percentage="65"
            description="Canu is a fork of the Celera Assembler, designed for high-noise single-molecule sequencing (such as the PacBio RS II/Sequel or Oxford Nanopore MinION)."
            image={canuimg}
          />
        </Col>
        <Col md="6" lg="3">
          <Project
            name="Alphafold"
            state="In progress"
            color="warning"
            percentage="20"
            description="Etiam rhoncus. Maecenas tempus, tellus eget condimentum rhoncus, sem quam semper libero, sit amet adipiscing sem neque sed ipsum."
            image={alphafold}
          />
        </Col>
        <Col md="6" lg="3">
          <Project
            name="Somethingelse"
            state="Finished"
            color="success"
            percentage="100"
            description="Nam pretium turpis et arcu. Duis arcu tortor, suscipit eget, imperdiet nec, imperdiet iaculis, ipsum. Sed aliquam ultrices mauris."
            image={blast}
          />
        </Col>
        <Col md="6" lg="3">
          <Project
            name="One more tool"
            state="On hold"
            color="danger"
            percentage="0"
            description="Curabitur ligula sapien, tincidunt non, euismod vitae, posuere imperdiet, leo. Maecenas malesuada. Praesent congue erat at massa."
            image={alphafold}
          />
        </Col>
      </Row>
    </Container>
  </React.Fragment>
);}

export default Apps;
