import React, { useCallback, useMemo, useRef, useState } from 'react';
import { Helmet } from "react-helmet-async";
import {
    Button, Card, Col, Container, Form, Row, Tab, Nav, Dropdown,
    DropdownButton, Modal
} from "react-bootstrap";
import Select from "react-select";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faPlus } from "@fortawesome/free-solid-svg-icons";
import AddInputDlg from "./AddInputDlg";
import AddOutputDlg from "./AddOutputDlg";

import Header from "./Header";

import { AgGridReact } from 'ag-grid-react';
import 'ag-grid-community/styles/ag-grid.css';
import 'ag-grid-community/styles/ag-theme-alpine.css';

interface TabsWithTextLabelType {
    name: string;
    className?: string;
}

const Props = () => {
    const containerStyle = useMemo(() => ({ width: '100%', height: '300px' }), []);
    const gridStyle = useMemo(() => ({ height: '100%', width: '100%' }), []);
    const [rowData, setRowData] = useState();
    const [columnDefs, setColumnDefs] = useState([
        { field: 'function', rowDrag: true },
        { field: 'type' },
        { field: 'parameter', width: 100 },
        { field: 'separator' },
        { field: 'value' },
        { field: 'title' },
        { field: 'description' },
        { field: 'readonly' },
        { field: 'array' },
        { field: 'array_separator' },
    ]);

    const defaultColDef = useMemo(() => {
        return {
            width: 170,
            sortable: true,
            filter: true,
        };
    }, []);

    const onGridReady = useCallback((params) => {
        fetch('../io.json')
            .then((resp) => resp.json())
            .then((data) => setRowData(data));
    }, []);

    return (

        <div style={containerStyle}>
            <div style={gridStyle} className="ag-theme-alpine">
                <AgGridReact
                    rowData={rowData}
                    columnDefs={columnDefs}
                    defaultColDef={defaultColDef}
                    rowDragManaged={true}
                    animateRows={true}
                    onGridReady={onGridReady}
                ></AgGridReact>
            </div>
        </div>

    );
};


const IOFormRow = () => (
    <Card>
        <Card.Header>
            <Card.Title>Inputs and Outputs</Card.Title>
            <h6 className="card-subtitle text-muted">Please define inputs and outputs of your application</h6>
        </Card.Header>
        <Card.Body>
            <Form>
                <Row>
                    <Col md={12}>
                        <Props />
                    </Col>
                </Row>

            </Form>
        </Card.Body>
    </Card>
);

const IOImageRow = () => (
    <Card>
        <Card.Header>
            <Card.Title>Command Line</Card.Title>
            <h6 className="card-subtitle text-muted">Command line built from inputs/outputs/options</h6>
        </Card.Header>
        <Card.Body>
            <Form>
                <Row>
                    <Col md={12}>
                        <Form.Group className="mb-3">
                            <Form.Label>Tool Command Line</Form.Label>
                            <Form.Control
                                as="textarea"
                                placeholder=""
                                value="canu -p ecoli -d ecoli-erate-0.075 genomeSize=4.8m correctedErrorRate=0.075 -trimmed -corrected -pacbio ecoli/ecoli.trimmedReads.fasta.gz"
                                style={{ height: "100px" }}
                            />
                        </Form.Group>
                    </Col>

                </Row>

            </Form>
        </Card.Body>
    </Card>
);

const IOModals = () => {
    const [show, setShow] = useState(false);
    const [output, setOutput] = useState(false);

    const handleClose = () => { setShow(false); setOutput(false); }
    const handleShow = () => setShow(true);
    const handleOutput = () => setOutput(true);

    
    return (
    <>
    <DropdownButton
    variant="primary" className="float-end mt-n1" title="Create New"
>
    <Dropdown.Item eventKey="1" onClick={handleShow}>Parameter/argument</Dropdown.Item>
    <Dropdown.Item eventKey="2" onClick={handleOutput}>Output</Dropdown.Item>
</DropdownButton>
<Modal show={show} onHide={handleClose}>
    <Modal.Header closeButton>
        <Modal.Title>Create a New Input</Modal.Title>
    </Modal.Header>
    <Modal.Body>
        <AddInputDlg />
    </Modal.Body>
    <Modal.Footer>
        <Button variant="secondary" onClick={handleClose}>
            Cancel
        </Button>
        <Button variant="primary" onClick={handleClose}>
            Add Input
        </Button>
    </Modal.Footer>
</Modal>
<Modal show={output} onHide={handleClose}>
    <Modal.Header closeButton>
        <Modal.Title>Create a New Output</Modal.Title>
    </Modal.Header>
    <Modal.Body>
        <AddOutputDlg />
    </Modal.Body>
    <Modal.Footer>
        <Button variant="secondary" onClick={handleClose}>
            Cancel
        </Button>
        <Button variant="primary" onClick={handleClose}>
            Add Output
        </Button>
    </Modal.Footer>
</Modal>
</>
);
    }

const EditorIO = () => {
       return (
        <React.Fragment>
            <IOModals />

            <Helmet title="Inputs and Outputs" />
            <Container fluid className="p-0">
                <Header />
                <Row>
                    <Col lg="12">
                        <IOFormRow />
                        <IOImageRow />
                        <Button variant="primary">Save</Button>

                    </Col>
                </Row>
            </Container>
        </React.Fragment>
    );
};

export default EditorIO;
export {IOModals, IOFormRow, IOImageRow};
