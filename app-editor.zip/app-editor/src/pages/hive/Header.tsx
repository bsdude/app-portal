import React from "react";

import { Button, Col, Dropdown, Row } from "react-bootstrap";
import { Calendar, Filter, RefreshCw } from "react-feather";
import { useNavigate } from "react-router-dom";


const Header = () => {
  const navigate = useNavigate();
  return (
    <Row className="mb-2 mb-xl-3">
      <Col xs="auto" className="d-none d-sm-block">
        <h3>App Editor</h3>
      </Col>

      <Col xs="auto" className="ms-auto text-end mt-n1">
        <Button variant="primary" className="shadow-sm">
          <RefreshCw className="feather" />
        </Button>
        &nbsp;
        <Button className="shadow-sm"
          type="submit"
          variant="primary"
          onClick={ () =>     navigate('/apps/list') }
        >
          Save
        </Button>
        &nbsp;
        <Button className="shadow-sm"
          type="submit"
          variant="primary"
          onClick={ () =>     navigate('/apps/list') }
        >
          Cancel
        </Button>


      </Col>
    </Row>
  );
};

export default Header;
