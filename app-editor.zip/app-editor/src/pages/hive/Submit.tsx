import React from "react";
import { Helmet } from "react-helmet-async";
import { Button, Card, Col, Container, Form, Row } from "react-bootstrap";
import Select from "react-select";



import Header from "./Header";

const options = [
  { value: "AK", label: "Annotations" },
  { value: "HI", label: "AMR" },
  { value: "CA", label: "Classifications" },
  { value: "NV", label: "Downloaders" },
  { value: "OR", label: "DNA Tools" },
  { value: "WA", label: "Other" },
]

const FormRow = () => (
  <Card>
    <Card.Header>
      <Card.Title>Test and Submit application</Card.Title>
      <h6 className="card-subtitle text-muted">Application cannot be used untill it passed tests and submitted</h6>
    </Card.Header>
    <Card.Body>
      <Form>
      <Row>
          <Col md={6}>
            <Form.Group className="mb-3">
              <Form.Label>Number of Parallel Threads</Form.Label>
              <Form.Control type="text" name="app_name" placeholder="" />
            </Form.Group>
          </Col>
          <Col md={6}>
          <Form.Group className="mb-3">
              <Form.Label>Amount of RAM</Form.Label>
              <Form.Control type="text" name="app_version" placeholder="" />
            </Form.Group>
          </Col>
        </Row>
 
      </Form>
    </Card.Body>
  </Card>
);

const ImageRow = () => (
    <Card>
    <Card.Header>
      <Card.Title>App Return Codes</Card.Title>
      <h6 className="card-subtitle text-muted">Application executable return code to identify successful execution</h6>
    </Card.Header>
    <Card.Body>
      <Form>
      <Row>
          <Col md={6}>
            <Form.Group className="mb-3">
              <Form.Label>Success Codes</Form.Label>
              <Form.Control
          as="textarea"
          placeholder="Type in comma-separated list of success codes"
          style={{ height: "100px" }}
        />
            </Form.Group>
          </Col>
          <Col md={6}>
          <Form.Group className="mb-3">
              <Form.Label>Failure Codes</Form.Label>
              <Form.Control
          as="textarea"
          placeholder="Type in comma-separated list of failure codes"
          style={{ height: "100px" }}
        />
            </Form.Group>
          </Col>
        </Row>
 
      </Form>
    </Card.Body>
  </Card>
);

const EditorSubmit = () => (
  <React.Fragment>
    <Helmet title="General Settings" />
    <Container fluid className="p-0">
      <Header />
      <Row>
        <Col lg="12">
          <FormRow />
          <ImageRow />
          <Button variant="primary">Save</Button>
        </Col>
      </Row>
    </Container>
  </React.Fragment>
);

export default EditorSubmit;
