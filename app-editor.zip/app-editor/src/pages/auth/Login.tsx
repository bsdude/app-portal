import React from "react";
import { Link } from "react-router-dom";
import { Helmet } from "react-helmet-async";

import { Button } from "react-bootstrap";
import { Navigate } from 'react-router-dom'


const LoginPage = () => {
   let userID = document.cookie.replace(/(?:(?:^|.*;\s*)userName\s*\=\s*([^;]*).*$)|^.*$/, "$1");

   if (!userID || userID === "Guest") {
      return (
         <React.Fragment>
            <Helmet title="Please Login" />
            <div className="text-center">
               <h2 className="display-3 fw-bold">App Portal</h2>
               <br />
               <p className="h1">Please log in</p>
               <br />
               <p className="h2 fw-normal mt-3 mb-4">
                  In order to use App Portal you need an active Hive account.
               </p>
               <br />
               <Link to="/apps/list">
                  <Button variant="primary" size="lg">
                     Login
                  </Button>
               </Link>
            </div>
         </React.Fragment>
      )
   }
   else {
      <Navigate replace to='/apps/list' />
   }
}

export default LoginPage;
