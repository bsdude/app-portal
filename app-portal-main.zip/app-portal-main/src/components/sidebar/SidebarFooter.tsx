import React from "react";

const SidebarFooter = () => {
  return (
    <div className="sidebar-cta">
     
    </div>
  );
};

export default SidebarFooter;
