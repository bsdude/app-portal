import React from "react";

const Content: React.FC = ({ children }) => (
  <div className="content">{children}</div>
);

export default Content;
