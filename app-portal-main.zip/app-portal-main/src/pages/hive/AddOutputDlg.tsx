import React, { useState } from "react";
import { Helmet } from "react-helmet-async";
import { Button, Card, Col, Container, Modal, Row, Form } from "react-bootstrap";
import Select from "react-select";


const options = [
  { value: "string", label: "String" },
  { value: "type1", label: "Type 1" },
  { value: "type1", label: "Type 2" },
  { value: "type1", label: "Type 3" },
  { value: "type1", label: "Type 4" },
  { value: "type1", label: "Type 5" },
  { value: "type1", label: "Type 6" },
  { value: "type1", label: "Type 7" },
  { value: "type1", label: "Type 8" },
  { value: "type1", label: "Type 9" },
  { value: "type1", label: "Type 10" },
  { value: "type1", label: "Type 11" },
];


const AddOutputDlg = () => {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  return (
    <Form>
         <Form.Group as={Row} className="mb-3">
            <Form.Label column sm={2} className="text-sm-right">
              Name
            </Form.Label>
            <Col sm={10}>
              <Form.Control type="email" name="email" placeholder="Trimmed Reads" />
            </Col>
          </Form.Group>
     
   
          <Form.Group as={Row} className="mb-3">
            <Form.Label column sm={2} className="text-sm-right">
              Description
            </Form.Label>
            <Col sm={10}>
              <Form.Control type="email" name="email" placeholder="Fasta formatted Trimmed Reads" />
            </Col>
          </Form.Group>

   

      <Form.Group as={Row} className="mb-3">
        <Form.Label column sm={2} className="text-sm-right">
          Type
        </Form.Label>
        <Col sm={10}>
        <Select
              className="react-select-container"
              classNamePrefix="react-select"
              options={options}
              isSearchable
            />
        </Col>
      </Form.Group>

   

      <Form.Group as={Row} className="mb-3">
        <Form.Label column sm={2} className="text-sm-right">
          Default Value
        </Form.Label>
        <Col sm={10}>
          <Form.Control
            as="textarea"
            name="textarea"
            placeholder=""
          />
        </Col>
      </Form.Group>

     
    </Form>
  );
};

export default AddOutputDlg;
