import React, { useState } from "react";
import { Helmet } from "react-helmet-async";
import { Button, Card, Col, Container, Modal, Row, Form } from "react-bootstrap";
import Select from "react-select";


const options = [
  { value: "string", label: "String" },
  { value: "type1", label: "Type 1" },
  { value: "type1", label: "Type 2" },
  { value: "type1", label: "Type 3" },
  { value: "type1", label: "Type 4" },
  { value: "type1", label: "Type 5" },
  { value: "type1", label: "Type 6" },
  { value: "type1", label: "Type 7" },
  { value: "type1", label: "Type 8" },
  { value: "type1", label: "Type 9" },
  { value: "type1", label: "Type 10" },
  { value: "type1", label: "Type 11" },
];


const AddInputDlg = () => {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  return (
    <Form>
      <Row>
        <Col md={6}>

          <Form.Group as={Row} className="mb-3">
            <Form.Label column sm={4} className="text-sm-right">
              Name
            </Form.Label>
            <Col sm={8}>
              <Form.Control type="email" name="email" placeholder="Genome Size" />
            </Col>
          </Form.Group>
        </Col>

        <Col md={3}>
          <Form.Check
            label="Required"
            type="checkbox"
          />
        </Col>
        <Col md={3}>
          <Form.Check
            label="Read-only"
            type="checkbox"
          />
        </Col>
      </Row>

   
          <Form.Group as={Row} className="mb-3">
            <Form.Label column sm={2} className="text-sm-right">
              Description
            </Form.Label>
            <Col sm={10}>
              <Form.Control type="email" name="email" placeholder="Maximum size of Genome" />
            </Col>
          </Form.Group>

   

      <Form.Group as={Row} className="mb-3">
        <Form.Label column sm={2} className="text-sm-right">
          Type
        </Form.Label>
        <Col sm={10}>
        <Select
              className="react-select-container"
              classNamePrefix="react-select"
              options={options}
              isSearchable
            />
        </Col>
      </Form.Group>


      <Row>
        <Col md={6}>

          <Form.Group as={Row} className="mb-3">
            <Form.Label column sm={4} className="text-sm-right">
              Prefix
            </Form.Label>
            <Col sm={8}>
              <Form.Control type="email" name="email" placeholder="genomeSize" />
            </Col>
          </Form.Group>
        </Col>

        <Col md={6}>
        <Form.Group as={Row} className="mb-3">
            <Form.Label column sm={4} className="text-sm-right">
              Separator
            </Form.Label>
            <Col sm={8}>
            <Form.Select
                id="exampleCustomSelect"
                name="customSelect"
                className="mb-3"
              >
                <option value="">=</option>
                <option>[space]</option>
                
              </Form.Select>
            </Col>
          </Form.Group>
        </Col>
       </Row>


       <Row>
        <Col md={6}>

      <Form.Group as={Row} className="mb-3">
        <Form.Label column sm={4} className="text-sm-right pt-sm-0">
          Array
        </Form.Label>
        <Col sm={8}>
          <Form.Check
            type="checkbox"
            id="checkbox"
            label="Value is an array"            
          />
        </Col>
      </Form.Group>
      </Col>
      <Col md={6}>
        <Form.Group as={Row} className="mb-3">
            <Form.Label column sm={4} className="text-sm-right">
              Formatter
            </Form.Label>
            <Col sm={8}>
            <Form.Select
                id="exampleCustomSelect"
                name="customSelect"
                className="mb-3"
              >
                <option value="">v1,v2,v3</option>
                <option value="">v1 v2 v3</option>
                <option value="">v1;v2;v3</option>
                <option value="">-p=v1 -p=v2 -p=v3</option>
              </Form.Select>
            </Col>
          </Form.Group>
        </Col>

      </Row>

      <Form.Group as={Row} className="mb-3">
        <Form.Label column sm={2} className="text-sm-right">
          Default Value
        </Form.Label>
        <Col sm={10}>
          <Form.Control
            as="textarea"
            name="textarea"
            placeholder="4.8m"
          />
        </Col>
      </Form.Group>

     
    </Form>
  );
};

export default AddInputDlg;
