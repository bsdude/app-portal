import React from "react";
import { Helmet } from "react-helmet-async";
import { Button, Card, Col, Container, Form, Row } from "react-bootstrap";
import Select from "react-select";



import Header from "./Header";

const options = [
  { value: "AK", label: "Annotations" },
  { value: "HI", label: "AMR" },
  { value: "CA", label: "Classifications" },
  { value: "NV", label: "Downloaders" },
  { value: "OR", label: "DNA Tools" },
  { value: "WA", label: "Other" },
]

const FormRow = () => (
  <Card>
    <Card.Header>
      <Card.Title>General Settings</Card.Title>
      <h6 className="card-subtitle text-muted">Please fill general app information</h6>
    </Card.Header>
    <Card.Body>
      <Form>
        <Row>
          <Col md={6}>
            <Form.Group className="mb-3">
              <Form.Label>App Name</Form.Label>
              <Form.Control type="text" name="app_name" placeholder="Canu" />
            </Form.Group>
            <Form.Group className="mb-3">
              <Form.Label>App Description</Form.Label>
              <Form.Control type="text" name="app_description" placeholder="Canu is a fork of the Celera Assembler, designed for high-noise single-molecule sequencing" />
            </Form.Group>

            <Form.Group className="mb-3">
              <Form.Label>Source URL</Form.Label>
              <Form.Control type="text" name="app_name" placeholder="https://github.com/marbl/canu" />
            </Form.Group>
          </Col>
          <Col md={6}>
            <Form.Group className="mb-3">
              <Form.Label>App Version</Form.Label>
              <Form.Control type="text" name="app_version" placeholder="2.2" />
            </Form.Group>
            <Form.Group className="mb-3">
              <Form.Label>App License</Form.Label>
              <Form.Select
                id="exampleCustomSelect"
                name="customSelect"
                className="mb-3"
              >
                <option value="">GPL</option>
                <option>MIT</option>
                <option>Apache</option>
                <option>BSD</option>
                <option>LGPL</option>
                <option>Other</option>
              </Form.Select>
            </Form.Group>
            <Form.Group className="mb-3">
              <Form.Label>Labels</Form.Label>
              <Select
                className="react-select-container"
                classNamePrefix="react-select"
                options={options}
                isMulti
              />
            </Form.Group>


          </Col>
        </Row>

      </Form>
    </Card.Body>
  </Card>
);

const ImageRow = () => (
  <Card>
    <Card.Header>
      <Card.Title>App Image Settings</Card.Title>
      <h6 className="card-subtitle text-muted">Acceptable formats are Singularity and Docker</h6>
    </Card.Header>
    <Card.Body>
      <Form>
        <Row>
        
          <Col md={6}>
            <Form.Group className="mb-3">
              <Form.Label>Select App Image</Form.Label>
              <Form.Select name="app_image">
                <option>Canu_2.2_Docker.img</option>
                <option>Some_Other_Image_Docker.img</option>
                <option>Yet_Another_Image_Docker.img</option>
                <option disabled>_________</option>
                <option>Upload a new image...</option>
              </Form.Select>
            </Form.Group>
          </Col>
          <Col md={6}>
          <Form.Group className="mb-3">
              <Form.Label>Executable with full path</Form.Label>
              <Form.Control type="text" name="app_executable" placeholder="/opt/canu/bin/canu" />
            </Form.Group>
          </Col>
        </Row>
        <Row>
          <Col md={12}>
          <Form.Group className="mb-3">
              <Form.Label>Test case command line arguments</Form.Label>
              <Form.Control type="text" name="app_cli" placeholder="canu --help" />
            </Form.Group>
          </Col>
        </Row>
        <Row>
        <Col md={12}>
        <Form.Control
          as="textarea"
          placeholder="canu [-haplotype|-correct|-trim] \
          [-s <assembly-specifications-file>] \
          -p <assembly-prefix> \
          -d <assembly-directory> \
          genomeSize=<number>[g|m|k] \
          [other-options] \
          [-trimmed|-untrimmed|-raw|-corrected] \
          [-pacbio|-nanopore|-pacbio-hifi] *fastq"
          style={{ height: "200px" }}
        />
      </Col>
        </Row>
      </Form>

    </Card.Body>
  </Card>
);

const EditorGeneral = () => (
  <React.Fragment>
    <Helmet title="General Settings" />
    <Container fluid className="p-0">
      <Header />
      <Row>
        <Col lg="12">
          <FormRow />
          <ImageRow />
          <Button variant="primary">Save Changes</Button>
        </Col>
      </Row>
    </Container>
  </React.Fragment>
);

export default EditorGeneral;
