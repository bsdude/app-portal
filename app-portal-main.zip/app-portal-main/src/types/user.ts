export type User = {
  id: string;
  displayName: string;
  email: string;
  password: string;
  avatar: File | any;
};
