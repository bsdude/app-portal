import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';

import { AppEditorComponent } from './app-editor.component';

describe('AppEditorComponent', () => {
  let component: AppEditorComponent;
  let fixture: ComponentFixture<AppEditorComponent>;

  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      declarations: [ AppEditorComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AppEditorComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
