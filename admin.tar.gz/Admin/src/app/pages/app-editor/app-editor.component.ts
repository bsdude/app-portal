import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-wizard',
  templateUrl: './app-editor.component.html',
  styleUrls: ['./app-editor.component.scss']
})

/**
 * Form wizard component
 */
export class AppEditorComponent implements OnInit {
 // bread crumb items
 breadCrumbItems: Array<{}>;

 constructor() { }

 ngOnInit() {
   this.breadCrumbItems = [{ label: 'Forms' }, { label: 'Form Wizard', active: true }];
 }

}
