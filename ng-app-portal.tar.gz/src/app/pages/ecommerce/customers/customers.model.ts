export interface Customers {
    id: number;
    username: string;
    phone: string;
    email: string;
    address: string;
    rating: string;
    balance: string;
    date: string;
}
