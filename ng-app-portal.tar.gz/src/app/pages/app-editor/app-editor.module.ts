import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HttpClientModule } from '@angular/common/http';

import { NgbNavModule, NgbTooltipModule, NgbDropdownModule } from "@ng-bootstrap/ng-bootstrap";
import { UIModule } from '../../shared/ui/ui.module';

import { AppEditorComponent } from '../app-editor/app-editor.component';
import { IosComponent } from '../app-editor/ios/ios.component';

import { ArchwizardModule } from 'angular-archwizard';
import { AgGridModule } from 'ag-grid-angular';

import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { DropzoneModule } from 'ngx-dropzone-wrapper';
import { DROPZONE_CONFIG } from 'ngx-dropzone-wrapper';
import { DropzoneConfigInterface } from 'ngx-dropzone-wrapper';
import { NgSelectModule } from '@ng-select/ng-select';


const config: DropzoneConfigInterface = {
    // Change this to your upload POST address:
    url: 'https://httpbin.org/post',
    maxFilesize: 100,
  };

@NgModule({
    declarations: [AppEditorComponent, IosComponent],
    imports: [
        CommonModule,
        UIModule,
        AgGridModule,
        HttpClientModule,
        ArchwizardModule,
        FormsModule,
        ReactiveFormsModule,
        DropzoneModule,
        NgSelectModule,
        NgbDropdownModule,
        NgbNavModule,
        NgbTooltipModule

    ],
    providers: [
        {
          provide: DROPZONE_CONFIG,
          useValue: config
        }
      ]
})

export class AppEditorModule { }
