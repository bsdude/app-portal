import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import {IosComponent} from './ios/ios.component';
import { FormBuilder, Validators, FormGroup } from '@angular/forms';
import { DropzoneConfigInterface } from 'ngx-dropzone-wrapper';



@Component({
  selector: 'app-wizard',
  templateUrl: './app-editor.component.html',
  styleUrls: ['./app-editor.component.scss']
})

/**
 * Form wizard component
 */
export class AppEditorComponent implements OnInit {
 // bread crumb items
 breadCrumbItems: Array<{}>;

 constructor(public formBuilder: FormBuilder, private http: HttpClient) { }


  /**
   * Returns form
   */
   get form() {
    return this.productForm.controls;
  }

  productForm: FormGroup;
  submit: boolean;

  config: DropzoneConfigInterface = {
    // Change this to your upload POST address:
    maxFilesize: 50,
    acceptedFiles: 'image/*',
    method: 'POST',
    uploadMultiple: false,
    accept: (file) => {
      this.onAccept(file);
    }
  };
  image = '';
  file = '';

  onAccept(file: any) {
    this.image = file.name;
    this.file = file;
  }

 ngOnInit() {
   this.breadCrumbItems = [{ label: 'Forms' }, { label: 'Form Wizard', active: true }];
   this.submit = false;

 }

  /**
   * Bootsrap validation form submit method
   */
   validSubmit() {
    this.submit = true;
    const formData = new FormData();
    formData.append('name', this.productForm.get('name').value);
    formData.append('manufacture_name', this.productForm.get('manufacture_name').value);
    formData.append('manufacture_brand', this.productForm.get('manufacture_brand').value);
    formData.append('price', this.productForm.get('price').value);
   // formData.append('image', this.file, this.image);

    this.http.post<any>(`http://localhost:8000/api/products`, formData)
      .subscribe((data) => {
        return data;
      });
  }

}
