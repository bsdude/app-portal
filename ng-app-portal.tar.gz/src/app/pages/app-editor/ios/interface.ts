export interface IOlympicData {
    function: string;
    type: string;
    prefix: string;
    separator: string;
    value: string;
    title: string;
    description: string;
    readonly: string;
    array: string;
    array_separator: string;
  }
