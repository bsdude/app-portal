import { Component, OnInit } from '@angular/core';

import { Project } from '../applist.model';

import { projectData } from '../projectdata';

@Component({
  selector: 'app-projectlist',
  templateUrl: './applist.component.html',
  styleUrls: ['./applist.component.scss']
})

/**
 * Projects-list component
 */
export class ApplistComponent implements OnInit {

 // bread crumb items
 breadCrumbItems: Array<{}>;

 projectData: Project[];

 constructor() { }

 ngOnInit() {
   this.breadCrumbItems = [{ label: 'Projects' }, { label: 'Projects List', active: true }];

   this.projectData = projectData;
 }
}
