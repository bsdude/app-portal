import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';

import { ApplistComponent } from './applist.component';

describe('ProjectlistComponent', () => {
  let component: ApplistComponent;
  let fixture: ComponentFixture<ApplistComponent>;

  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      declarations: [ ApplistComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ApplistComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
