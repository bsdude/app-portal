import React, { Component } from "react";
import PropTypes from "prop-types";
import { connect } from "react-redux";
import { isEmpty, size } from "lodash";
import ReactDragListView from "react-drag-listview/lib/index.js";

import {
  Button,
  Card,
  CardBody,
  Col,
  Container,
  Row,
  Badge,
  UncontrolledDropdown,
  DropdownToggle,
  DropdownMenu,
  DropdownItem,
  Label,
  Modal,
  ModalBody,
  ModalHeader,
  CardTitle,
  Table,
} from "reactstrap";
import ToolkitProvider, {
  Search,
} from "react-bootstrap-table2-toolkit/dist/react-bootstrap-table2-toolkit";
import BootstrapTable from "react-bootstrap-table-next";
import paginationFactory, {
  PaginationListStandalone,
  PaginationProvider,
} from "react-bootstrap-table2-paginator";
import * as moment from "moment";

import CommandLine from 'react-command-line';
import './cmdline.css'


//Import Breadcrumb
import Breadcrumbs from "components/Common/Breadcrumb";
import DeleteModal from "components/Common/DeleteModal";
import { Formik, Field, Form, ErrorMessage } from "formik";
import * as Yup from "yup";

import {
  getCustomers,
  addNewCustomer,
  updateCustomer,
  deleteCustomer,
} from "store/e-commerce/actions";

const messages = {
  'WELCOME_MESSAGE': 'canu -p ecoli -d ecoli-erate-0.075 genomeSize=4.8m correctedErrorRate=0.075 -trimmed -corrected -pacbio ecoli/ecoli.trimmedReads.fasta.gz',
  'INVALID_COMMAND': 'Invalid command. Try typing "help" to see a list of supported commands.'
}
const commands = {
  help: {
    fn: args => {
      return `Supported commands: foo
foo [args]: Echoes 'bar' and the arguments.
sleep: Waits for 5 seconds, then returns with a message.`
    }
  },
  foo: {
    fn: args => {
      return `bar. Arguments were: [${args.join(', ')}]`;
    }
  },
  sleep: {
    fn: args => {
      return new Promise((resolve, reject) => {
        setTimeout(() => {
          resolve('done!');
        }, 5000);
      });
    },
    isAsync: true
  }
}
class EcommerceCustomers extends Component {
  constructor(props) {
    super(props);
    this.node = React.createRef();
    this.state = {
      data: [
        {
          id: "1",
          io: "Input",
          type: "obj",
          prefix: "-p",
          separator: "<space>",
          default_value: "ecoli",
          title: "Input",
          description: "Input Obj",
          readonly: "false",
          array: "false",
          array_separator: "-"
        },
        {
          id: "2",
          io: "Input",
          type: "string",
          prefix: "genomeSize",
          separator: "=",
          default_value: "4.8m",
          title: "Genome Size",
          description: "Max Size of the Genome",
          readonly: "false",
          array: "false",
          array_separator: "-"
        },
        {
          id: "3",
          io: "Input",
          type: "string",
          prefix: "correctedErrorRate",
          separator: "=",
          default_value: "0.075",
          title: "Error Rate",
          description: "Corrected Error Rate",
          readonly: "false",
          array: "false",
          array_separator: "-"
        },
        {
          id: "4",
          io: "Output",
          type: "obj",
          prefix: "-",
          separator: "-",
          default_value: "<empty>",
          title: "Trimmed Reads",
          description: "Fasta formatted trimmed reads",
          readonly: "-",
          array: "-",
          array_separator: "-"
        },
      ],

    
      customers: [],
      customer: "",
      deleteModal: false,
    
    };
    this.handleCustomerClick = this.handleCustomerClick.bind(this);
    this.toggle = this.toggle.bind(this);
    this.handleCustomerClicks = this.handleCustomerClicks.bind(this);
    this.onClickDelete = this.onClickDelete.bind(this);
  }

  componentDidMount() {
    const { customers, onGetCustomers } = this.props;
    if (customers && !customers.length) {
      onGetCustomers();
    }
    this.setState({ customers });
  }

  // eslint-disable-next-line no-unused-vars
  componentDidUpdate(prevProps, prevState, snapshot) {
    const { customers } = this.props;
    if (!isEmpty(customers) && size(prevProps.customers) !== size(customers)) {
      this.setState({ customers: {}, isEdit: false });
    }
  }

  toggle() {
    this.setState(prevState => ({
      modal: !prevState.modal,
    }));
  }

  handleCustomerClicks = arg => {
    this.setState({ customer: arg });
    this.toggle();
  };

  onPaginationPageChange = page => {
    if (
      this.node &&
      this.node.current &&
      this.node.current.props &&
      this.node.current.props.pagination &&
      this.node.current.props.pagination.options
    ) {
      this.node.current.props.pagination.options.onPageChange(page);
    }
  };

  /* Insert,Update Delete data */

  toggleDeleteModal = () => {
    this.setState(prevState => ({
      deleteModal: !prevState.deleteModal,
    }));
  };

  onClickDelete = customer => {
    this.setState({ customer: customer });
    this.setState({ deleteModal: true });
  };

  handleDeleteCustomer = () => {
    const { onDeleteCustomer } = this.props;
    const { customer } = this.state;
    if (customer.id !== undefined) {
      onDeleteCustomer(customer);
      this.onPaginationPageChange(1);
      this.setState({ deleteModal: false });
    }
  };

  handleCustomerClick = arg => {
    const customer = arg;

    this.setState({
      customer: {
        id: customer.id,
        username: customer.username,
        phone: customer.phone,
        email: customer.email,
        address: customer.address,
        rating: customer.rating,
        walletBalance: customer.walletBalance,
        joiningDate: customer.joiningDate,
      },
      isEdit: true,
    });

    this.toggle();
  };

  handleValidDate = date => {
    const date1 = moment(new Date(date)).format("DD MMM Y");
    return date1;
  };

  render() {
    const that = this;
    const dragProps = {
      onDragEnd(fromIndex, toIndex) {
        const data = [...that.state.data];
        const item = data.splice(fromIndex, 1)[0];
        data.splice(toIndex, 0, item);
        that.setState({ data });
      },
      nodeSelector: "tr",
      handleSelector: "tr",
    };

    const dragProps1 = {
      onDragEnd(fromIndex1, toIndex1) {
        const data1 = [...that.state.data1];
        const item = data1.splice(fromIndex1, 1)[0];
        data1.splice(toIndex1, 0, item);
        that.setState({ data1 });
      },
      nodeSelector: "tr",
      handleSelector: "tr",
    };

    //meta title
    document.title = "App Editor | Application Portal";

    const { customers } = this.props;

    const customer = this.state.customer;

    const { isEdit, deleteModal } = this.state;

    const { onAddNewCustomer, onUpdateCustomer } = this.props;

    //pagination customization
    const pageOptions = {
      sizePerPage: 10,
      totalSize: customers.length, // replace later with size(customers),
      custom: true,
    };

    const defaultSorted = [
      {
        dataField: "id",
        order: "desc",
      },
    ];

    const { SearchBar } = Search;

    const selectRow = {
      mode: "checkbox",
    };

    return (
      <React.Fragment>
        <DeleteModal
          show={deleteModal}
          onDeleteClick={this.handleDeleteCustomer}
          onCloseClick={() => this.setState({ deleteModal: false })}
        />
        <div className="page-content">
          <Container fluid>
            <Breadcrumbs title="App Editor" breadcrumbItem="Inputs and Outputs Configuration" />


            <Row>

              <Col md={12}>
                <Card>
                  <CardBody>

                    <CardTitle className="h4">Inputs and Outputs</CardTitle>
                    <p className="card-title-desc">
                      To add an input or output use corresponding button
                    </p>

                    <Row>
                      <Col sm="8">
                        <div className="search-box me-2 mb-2 d-inline-block">

                        </div>
                      </Col>
                      <Col sm="2">
                        <div className="text-sm-end">
                          <Button
                            type="button"
                            color="success"
                            className="btn-rounded mb-2 me-2"
                            onClick={this.handleCustomerClicks}
                          >
                            <i className="mdi mdi-plus me-1" /> Add New
                            Input
                          </Button>
                        </div>
                      </Col>
                      <Col sm="2">
                        <div className="text-sm-end">
                          <Button
                            type="button"
                            color="success"
                            className="btn-rounded mb-2 me-2"
                            onClick={this.handleCustomerClicks}
                          >
                            <i className="mdi mdi-plus me-1" /> Add New
                            Output
                          </Button>
                        </div>
                      </Col>
                    </Row>
            
                    <div className="table-responsive">
                      <ReactDragListView {...dragProps}>
                        <Table className="table mb-0">
                          <thead>
                            <tr>
                              <th>IO</th>
                              <th>Type</th>
                              <th>Prefix</th>
                              <th>Separator</th>
                              <th>Default Value</th>
                              <th>Title</th>
                              <th>Description</th>
                              <th>Readonly</th>
                              <th>Array</th>
                              <th>Array Separator</th>
                            </tr>
                          </thead>

                          <tbody>
                            {this.state.data.map((item, index) => (
                              <tr key={index}>
                                <td>{item.io}</td>
                                <td>{item.type}</td>
                                <td>{item.prefix}</td>
                                <td>{item.separator}</td>
                                <td>{item.default_value}</td>
                                <td>{item.title}</td>
                                <td>{item.description}</td>
                                <td>{item.readonly}</td>
                                <td>{item.array}</td>
                                <td>{item.array_separator}</td>
                              </tr>
                            ))}
                          </tbody>
                        </Table>
                      </ReactDragListView>
                    </div>
                    <p>&nbsp;</p>
                    <div className="d-flex flex-wrap gap-2">
                        <Button
                          type="submit"
                          color="primary"
                        >
                          Save Changes
                      </Button>
                        <Button
                          type="submit"
                          color="secondary"
                        >
                          Cancel
                      </Button>
                      </div>                    
                  </CardBody>
                </Card>
              </Col>


            </Row>


          </Container>

          <Card>
            <CardBody>
              <CardTitle className="h4">Command line</CardTitle>
              <p className="card-title-desc">
                You can use the following CLI interface to see whether your command line works as expected
              </p>
              <CommandLine commands={commands} messages={messages} />
              <div className="modal-footer">
                <button
                  onClick={() => {
                    this.toggleRightbar();
                  }}
                  type="button" className="btn btn-primary">
                  Submit Application
                </button>
              </div>
            </CardBody>
          </Card>

        </div>
      </React.Fragment>
    );
  }
}

EcommerceCustomers.propTypes = {
  customers: PropTypes.array,
  onGetCustomers: PropTypes.func,
  onAddNewCustomer: PropTypes.func,
  onDeleteCustomer: PropTypes.func,
  onUpdateCustomer: PropTypes.func,
  className: PropTypes.any,
};

const mapStateToProps = ({ ecommerce }) => ({
  customers: ecommerce.customers,
});

const mapDispatchToProps = dispatch => ({
  onGetCustomers: () => dispatch(getCustomers()),
  onAddNewCustomer: customer => dispatch(addNewCustomer(customer)),
  onUpdateCustomer: customer => dispatch(updateCustomer(customer)),
  onDeleteCustomer: customer => dispatch(deleteCustomer(customer)),
});

export default connect(mapStateToProps, mapDispatchToProps)(EcommerceCustomers);
